package com.example.FirstSpringBoot.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.FirstSpringBoot.UserDao.UserDao;
import com.example.FirstSpringBoot.user.User;

@Controller
public class UserController {
    @Autowired
    private UserDao userDao;
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String welcome() {
        return "hello";
    
    }
    
   /* @RequestMapping(value = "/users", method = RequestMethod.GET)
    @ResponseBody
    public List<User> getAllUsers() {
        return userDao.getAll();
    }
    */
    
    @RequestMapping(value = "/users", method = RequestMethod.GET)
    public String getAllUsers(ModelMap model) {
     model.addAttribute("users", userDao.getAll());
     return "users";
    }

   /* @RequestMapping(value = "/add", method = RequestMethod.GET)
    @ResponseBody
    public User addUser(@RequestParam int id,@RequestParam String fname,@RequestParam String lname) {
        User u=new User(id,fname,lname);
        return userDao.addUser(u);
    }*/
  /* @RequestMapping(value = "/add", method = RequestMethod.GET)
    @ResponseBody
    public User addUser(@ModelAttribute User u) {
        return userDao.addUser(u);
    }*/
    @RequestMapping(value="/add", method = RequestMethod.GET)
	public String showTodos(@ModelAttribute User users,ModelMap model){
    
    	
    	model.addAttribute("show",userDao.addUser(users));
    
    
		return "show";
	} 
    
    
   /* @RequestMapping(value = "/delete", method = RequestMethod.GET)
    @ResponseBody
    public int deleteUser(@RequestParam int id,@RequestParam String fname,@RequestParam String lname) {
        return userDao.deleteById(id);
    }*/
    @RequestMapping(value="/delete", method = RequestMethod.GET)
   	public String deleteUser(@RequestParam int id,@RequestParam String fname,@RequestParam String lname,ModelMap model){
       
       	
       	model.addAttribute("show1",userDao.deleteById(id));
       
       
   		return "show1";
   	} 
       
    
   /* @RequestMapping(value = "/update", method = RequestMethod.GET)
    @ResponseBody
    public User update(@RequestParam int id,@RequestParam String fname,@RequestParam String lname) {
    	 User u=new User(id,fname,lname);
        return userDao.updateUser(u);
    }*/
    @RequestMapping(value="/update", method = RequestMethod.GET)
   	public String updateUser(@ModelAttribute User users,ModelMap model){
       
       	
       	model.addAttribute("show2",userDao.updateUser(users));
       
       
   		return "show2";
   	} 
   

}






