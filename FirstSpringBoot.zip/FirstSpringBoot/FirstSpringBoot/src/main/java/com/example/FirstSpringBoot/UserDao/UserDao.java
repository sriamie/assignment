package com.example.FirstSpringBoot.UserDao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.FirstSpringBoot.user.User;


@Component
public class UserDao {
    private static List<User> users = new ArrayList<User>();
    static {
        users.add(new User(1,"Sachin","Tendulkar"));
        users.add(new User(1,"Saurav","Ganguly"));
        users.add(new User(1,"Rahul","Dravid"));
    }
    public List<User> getAll() {
        return users;
    }
    public User getUserById(int id) {
        for (User u : users) {
            if (u.getId() == id)
                return u;
        }
        return null;
    }
    public User addUser(User u) {
        users.add(u);
        return u;
    }
    public int deleteById(int id) {
        for (User u : users) {
            if (u.getId() == id)
                users.remove(u);
            return 1;
        }
        return 0;
    }
    

		public User updateUser(User u) {
			  for (User u1 : users) {
			   if (u1.getId() == u.getId()) {
			    u1.setFname(u.getFname());
			    u1.setLname(u.getLname());
			    return u1;
			   }
			  }
			  users.add(u);
			  return null;
			 }
}
    

