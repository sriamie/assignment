package com.demo.FirstSpringBoot.model.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.demo.FirstSpringBoot.model.User;
@Component
public class UserDao {
    private List<User> users = new ArrayList<User>();
    public List getAll() {
        return users;
    }
    public User getUserById(int id) {
        for (User u : users) {
            if (u.getId() == id)
                return u;
        }
        return null;
    }
    public User addUser(User u) {
        users.add(u);
        return u;
    }
    public int deleteById(int id) {
        for (User u : users) {
            if (u.getId() == id)
                users.remove(u);
            return 1;
        }
        return 0;
    }
}